package com.svmc.t15.security.Alram;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.samsung.android.app.SemTimePickerDialog;
import com.samsung.android.widget.SemTimePicker;
import com.svmc.t15.security.FLAG_DEBUG;
import com.svmc.t15.security.R;
import com.svmc.t15.security.broadcast.AlarmBroadcast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AlarmShowVideo extends Activity {
    private static final String KEY_TIME_OFF = "KEY_TIME_OFF";
    private static final String KEY_TIME_ON = "KEY_TIME_ON";
    private static final String KEY_TIME = "KEY_TIME_ON";

    private SemTimePickerDialog mTimePicker;
    private final String DEFAULT_VALUE_TIME = "Click here";
    private List<ItemListView> list = new ArrayList<>();
    private SettingTimeAdapter customAdapter;
    private ImageButton btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_show_video);
        setColorStatusBar();
        mappingView();
        ListView listView = (ListView) findViewById(R.id.lv1);

        list.add(new ItemListView("Time on video", getTimeOn()));
        list.add(new ItemListView("Time off video", getTimeOff()));

        customAdapter = new SettingTimeAdapter(this, 0, list);

        listView.setAdapter(customAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);

                mTimePicker = new SemTimePickerDialog(AlarmShowVideo.this, new SemTimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(SemTimePicker semTimePicker, int i, int i1) {


                        Calendar calendar = Calendar.getInstance();
                        if (android.os.Build.VERSION.SDK_INT >= 23) {
                            calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH),
                                    semTimePicker.getHour(), semTimePicker.getMinute(), 0);
                        }

                        Log.d(FLAG_DEBUG.SHOW_ACTIVITY_FLAG, calendar.getTimeInMillis() + "");
                        Toast.makeText(AlarmShowVideo.this, semTimePicker.getHour() + " : " + semTimePicker.getMinute(), Toast.LENGTH_SHORT).show();

                        if (position == 0) { // click set time on
                            if (getTimeOn().equals(DEFAULT_VALUE_TIME)) {
                                setAlarm(calendar.getTimeInMillis(), semTimePicker.getHour(), semTimePicker.getMinute(), true);
                            } else {
                                setAlarm(calendar.getTimeInMillis(), semTimePicker.getHour(), semTimePicker.getMinute(), true);
                            }
                        } else if (position == 1) { // set time off
                            if (getTimeOff().equals(DEFAULT_VALUE_TIME)) {
                                setAlarm(calendar.getTimeInMillis(), semTimePicker.getHour(), semTimePicker.getMinute(), false);
                            } else {
                                setAlarm(calendar.getTimeInMillis(), semTimePicker.getHour(), semTimePicker.getMinute(), false);
                            }
                        }
                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlarmShowVideo.this.finish();
            }
        });
    }

    private void mappingView() {
        btnBack = findViewById(R.id.btnBackAlarmShowVideo);
    }

    public static final String ACTION_SET_TIME_ON = "ACTION_SET_TIME_ON";
    public static final String ACTION_SET_TIME_OFF = "ACTION_SET_TIME_OFF";

    public static final int REQUEST_CODE_TIME_ON = 1208;
    public static final int REQUEST_CODE_TIME_OFF = 1106;

    private void setAlarm(long time, int h, int s, boolean isTimeOn) {
        if (isTimeOn) {
            setTimeOn(h + ":" + s);
            list.get(0).setSubTitle(h + ":" + s);
            customAdapter.notifyDataSetChanged();
        } else {
            setTimeOff(h + ":" + s);
            list.get(1).setSubTitle(h + ":" + s);
            customAdapter.notifyDataSetChanged();
        }

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        Intent intent = new Intent(this, AlarmBroadcast.class);
        intent.setAction(isTimeOn ? ACTION_SET_TIME_ON : ACTION_SET_TIME_OFF);

        Intent i = new Intent("android.action.DISPLAY_NOTIFICATION");
        i.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);

        PendingIntent broadcast = PendingIntent.getBroadcast(
                AlarmShowVideo.this, isTimeOn ? REQUEST_CODE_TIME_ON : REQUEST_CODE_TIME_OFF,
                intent, PendingIntent.FLAG_UPDATE_CURRENT
        );

        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, time, AlarmManager.INTERVAL_DAY, broadcast);
    }

    private void setTimeOff(String timeOff) {
        SharedPreferences.Editor editor = getSharedPreferences(KEY_TIME, MODE_PRIVATE).edit();
        editor.putString(KEY_TIME_OFF, timeOff);
        editor.apply();
    }

    private void setTimeOn(String timeOn) {
        SharedPreferences.Editor editor = getSharedPreferences(KEY_TIME_ON, MODE_PRIVATE).edit();
        editor.putString(KEY_TIME_ON, timeOn);
        editor.apply();
    }


    private String getTimeOn() {
        SharedPreferences prefs = getSharedPreferences(KEY_TIME, MODE_PRIVATE);
        return prefs.getString(KEY_TIME_ON, DEFAULT_VALUE_TIME);
    }

    private String getTimeOff() {
        SharedPreferences prefs = getSharedPreferences(KEY_TIME, MODE_PRIVATE);
        return prefs.getString(KEY_TIME_OFF, DEFAULT_VALUE_TIME);
    }


    private void setColorStatusBar() {
        Window window = getWindow();

        // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.backgroundHeader));
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }
}
