package com.svmc.t15.security.Alram;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.svmc.t15.security.R;

import java.util.List;

public class SettingTimeAdapter extends ArrayAdapter {
    public SettingTimeAdapter(@NonNull Context context, int resource, List<ItemListView> list) {
        super(context, resource, list);
        mContext = context;
        listData = list;
    }

    private List<ItemListView> listData;
    private Context mContext;


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = convertView;
        if (v == null) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            v = inflater.inflate(R.layout.lv_item_setting_set_time_show_video, null);
        }

        TextView title = v.findViewById(R.id.lvItemTitle);
        TextView subTitle = v.findViewById(R.id.lvItemSubtile);

        title.setText(listData.get(position).getTitle());
        subTitle.setText(listData.get(position).getSubTitle());

        return v;

    }

    @Override
    public int getCount() {
        return listData.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
}
