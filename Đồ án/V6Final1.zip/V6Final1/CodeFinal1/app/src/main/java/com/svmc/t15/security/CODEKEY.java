package com.svmc.t15.security;

import com.google.android.exoplayer2.ui.PlayerView;
import com.svmc.t15.security.LoginPassWord.ChangePassWord;
import com.svmc.t15.security.LoginPassWord.LoginPassActivity;
import com.svmc.t15.security.NFC.Activity_NFC;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class CODEKEY {
    public static String KEY_PASS = "CODE-KEY-PASS";
    public static String KEY_NFC = "CODE-KEY-NFC";
    public static String TAG = "DEBUG";
    public static String KEY_ACTIVITY_NFC = "CODE-KEY-LOGIN-NFC";
    private static String KEY_CHANGE = "CODE-KEY-CHANGE";
    //TODO dang ky
    public static int VALUE_LOGIN =111;
    public static int VALUE_SIGIN = 100;
    public static int VALUE_LOGOUT = 0;
    public static int VALUE_LOCK = 200;
    public static int VALUE_CHANGE_LOCK_NFC = 300;
    public static int VALUE_CHANGE_NEW_NFC = 400;
    public static int VALUE_CONFIRM = 500;


    public static String getMD5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] messageDigest = md.digest(input.getBytes());
            return convertByteToHex1(messageDigest);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    private static String convertByteToHex1(byte[] data) {
        BigInteger number = new BigInteger(1, data);
        String hashtext = number.toString(16);
        // Now we need to zero pad it if you actually want the full 32 chars.
        while (hashtext.length() < 32) {
            hashtext = "0" + hashtext;
        }
        return hashtext;
    }
    public void TurnOfAtivity(){
        if(LoginPassActivity.Regiter != null) {
            LoginPassActivity.Regiter.finish();
        }
        if(MainActivity.contextMainActivity != null){
            MainActivity.contextMainActivity.finish();
        }
        if(LoginPassActivity.loginPass != null) {
            LoginPassActivity.loginPass.finish();
        }
        if(Screen_Lock.contextSceenLock != null){
            Screen_Lock.contextSceenLock.finish();
        }
        if(ChangePassWord.changePassWord != null){
            ChangePassWord.changePassWord.finish();
        }
        if(Activity_NFC.activity_nfc != null){
            Activity_NFC.activity_nfc.finish();
        }
        if(ShowVideoActivity.showVideoActivity != null){
            ShowVideoActivity.showVideoActivity.finish();
        }
    }
}
