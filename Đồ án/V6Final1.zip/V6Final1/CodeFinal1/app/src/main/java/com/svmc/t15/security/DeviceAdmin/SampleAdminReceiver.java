package com.svmc.t15.security.DeviceAdmin;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;
public class SampleAdminReceiver extends DeviceAdminReceiver {
    String TAG = "DEBUG";
    void showToast(Context context, CharSequence msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onEnabled(Context context, Intent intent) {

        Log.d(TAG, "onEnabled: Device admin enabled");
    }
    @Override
    public void onDisabled(Context context, Intent intent) {
        Log.d(TAG, "onDisabled: Device admin disabled");
    }
}