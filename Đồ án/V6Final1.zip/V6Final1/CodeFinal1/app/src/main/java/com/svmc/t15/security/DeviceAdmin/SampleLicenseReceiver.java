package com.svmc.t15.security.DeviceAdmin;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.samsung.android.knox.license.KnoxEnterpriseLicenseManager;


public class SampleLicenseReceiver extends BroadcastReceiver {

    private int DEFAULT_ERROR_CODE = -1;
    private String TAG = "DEBUG";
    private void showToast(Context context, int msg_res) {
        Toast.makeText(context, context.getResources().getString(msg_res), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent == null) {
            // No intent action is available
            Log.d(TAG, "onReceive: No intent action is available");
            return;
        } else {
            String action = intent.getAction();
            if (action == null) {
                // No intent action is available
                Log.d(TAG, "onReceive: No intent action is available");

                return;
            }  else if (action.equals(KnoxEnterpriseLicenseManager.ACTION_LICENSE_STATUS)) {
                // License key activation result Intent is obtained
                int errorCode = intent.getIntExtra(KnoxEnterpriseLicenseManager.EXTRA_LICENSE_ERROR_CODE, DEFAULT_ERROR_CODE);

                if (errorCode == KnoxEnterpriseLicenseManager.ERROR_NONE) {
                    // License key activated successfully
                    //showToast(context, R.string.license_key_activated_successfully);
                    Log.d(TAG, "onReceive:License key activated successfully ");
                    //Log.d("SampleLicenseReceiver", context.getString(R.string.license_key_activated_successfully));
                    return;
                } else {
                    // License key activation failed
                    // Display license key error message
                    Log.d(TAG, "onReceive: license key error message");
                    
                    return;
                }
            }
        }
    }
}
