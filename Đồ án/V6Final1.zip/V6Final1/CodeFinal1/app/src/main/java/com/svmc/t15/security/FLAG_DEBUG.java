package com.svmc.t15.security;

public class FLAG_DEBUG {
    public static final String SHOW_ACTIVITY_FLAG = "SHOW_ACTIVITY_FLAG";
    public static final String VIDEO_HANDLER_FLAG = "VIDEO_HANDLER_FLAG";
}
