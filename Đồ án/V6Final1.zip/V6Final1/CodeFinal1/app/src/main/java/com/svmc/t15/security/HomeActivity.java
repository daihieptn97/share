package com.svmc.t15.security;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.core.content.ContextCompat;

import com.svmc.t15.security.Alram.AlarmShowVideo;
import com.svmc.t15.security.Knox.MyKnox;
import com.svmc.t15.security.LoginPassWord.ChangePassWord;
import com.svmc.t15.security.LoginPassWord.LoginPassActivity;
import com.svmc.t15.security.NFC.Activity_NFC;

public class HomeActivity extends Activity {

    public static Activity homeActivity;
    private MyKnox myKnox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hone);
        Init();
        homeActivity = this;
        SetBarColor();
        new CODEKEY().TurnOfAtivity();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK){
            //finish();
        }
        return super.onKeyDown(keyCode, event);
    }

    //    TODO Test
    void SetBarColor() {
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.ColorWhite ));
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    private void Init() {

        myKnox = new MyKnox(this);

        myKnox.setAdminRemovable(false);
        myKnox.setRemoveApp(false);
        myKnox.setShowdow(false);
        myKnox.setResetFactory(false);
        myKnox.setLockScreenState(false);

        findViewById(R.id.btn_logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, LoginPassActivity.class);
                intent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_LOGOUT);
                startActivityForResult(intent, CODEKEY.VALUE_LOGOUT);

            }
        });
        findViewById(R.id.btn_changePass).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, ChangePassWord.class));
            }
        });

        findViewById(R.id.btn_changeNFC).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, Activity_NFC.class);
                intent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_CHANGE_LOCK_NFC);
                startActivity(intent);
            }
        });
        findViewById(R.id.btn_setAlarm).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, AlarmShowVideo.class);
                startActivity(intent);
            }
        });
    }

    private String GetNFC() {
        return getSharedPreferences(CODEKEY.KEY_NFC, MODE_PRIVATE).getString(CODEKEY.KEY_NFC, null);
    }

    private String GetPASS() {
        return getSharedPreferences(CODEKEY.KEY_PASS, MODE_PRIVATE).getString(CODEKEY.KEY_PASS, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CODEKEY.VALUE_LOGOUT) {
            if (resultCode == Activity.RESULT_OK) {
                myKnox.ExitApp();
                finish();
                System.exit(0);
            }

        }
    }//onActivityResult
}
