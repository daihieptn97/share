package com.svmc.t15.security.Knox;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.util.Log;
import android.view.KeyEvent;

import com.samsung.android.knox.EnterpriseDeviceManager;
import com.samsung.android.knox.application.ApplicationPolicy;
import com.samsung.android.knox.container.KnoxContainerManager;
import com.samsung.android.knox.custom.CustomDeviceManager;
import com.samsung.android.knox.custom.SettingsManager;
import com.samsung.android.knox.custom.SystemManager;
import com.samsung.android.knox.devicesecurity.PasswordPolicy;
import com.samsung.android.knox.kiosk.KioskMode;
import com.samsung.android.knox.nfc.NfcPolicy;
import com.samsung.android.knox.restriction.RestrictionPolicy;
import com.svmc.t15.security.DeviceAdmin.SampleAdminReceiver;

import java.util.ArrayList;
import java.util.List;
/* TODO
Delte admin
lock or unLock phone
Remove App
Kill app
*/


public class MyKnox {
    private EnterpriseDeviceManager edm;
    private ApplicationPolicy appPolicy;
    private RestrictionPolicy rp;
    private CustomDeviceManager cdm;
    private SystemManager kcsm;
    private KnoxContainerManager kcm;
    private String TAG = "DEBUG";
    private Context context;

    public MyKnox(Context context) {
        edm = EnterpriseDeviceManager.getInstance(context);
        appPolicy = edm.getApplicationPolicy();
        rp = edm.getRestrictionPolicy();
        cdm = CustomDeviceManager.getInstance();
        kcsm = cdm.getSystemManager();

        this.context = context;
    }

    public boolean setLockScreenState(boolean set) {
        try {
            // disallow multiple widgets on Lock screen.
            rp.setLockScreenState(set);
        } catch (Exception e) {
            Log.d(TAG, "resetPass: " + e);
            return false;
        }
        return true;
    }

    //TODO true la cho phep - false la khong cho phep
    public boolean setResetFactory(boolean _set) {
        try {
            rp.allowPowerOff(_set);
        } catch (Exception e) {
            Log.d(TAG, "setShowdow: " + e);
            return false;
        }
        return true;
    }

    //TODO true la cho phep - false la khong cho phep
    public boolean setShowdow(boolean _set) {
        try {
            rp.allowPowerOff(_set);
        } catch (Exception e) {
            Log.d(TAG, "setShowdow: " + e);
            return false;
        }
        return true;
    }

    // TODO true la xoa duoc app , false la khong cho xoa ap
    public boolean setRemoveApp(boolean _set) {
        try {
            if (_set) {
                appPolicy.setApplicationUninstallationEnabled(context.getPackageName());
            } else {
                appPolicy.setApplicationUninstallationDisabled(context.getPackageName());
            }
        } catch (Exception e) {
            Log.d(TAG, "setNoRemoveApp: " + e);
            return false;
        }
        return true;
    }

    // TODO true la cho xoa admin , false la khogn cho xoa admin
    public boolean setAdminRemovable(boolean _set) {
        try {
            edm.setAdminRemovable(_set);
        } catch (Exception e) {
            Log.d(TAG, "setAdmin: " + e);
            return false;
        }
        return true;
    }

    public boolean removeActiveAdmin() {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            dpm.removeActiveAdmin(new ComponentName(context, SampleAdminReceiver.class));
        } catch (Exception e) {
            Log.d(TAG, "removeActiveAdmin: " + e);
            return false;
        }
        return true;
    }

    // TODO false -> block ; true -> unlock
    public boolean setNFC(boolean _set) {
        try {
            NfcPolicy nfcPolicy = edm.getNfcPolicy();
            nfcPolicy.startNFC(_set);
        } catch (Exception e) {
            Log.d(TAG, "setNFC: " + e);
            e.printStackTrace();
            return false;
        }
        return true;
    }

    // TODO false -> block ; true -> unlock
    public boolean setToasts(boolean _set) {
        try {
            kcsm.setToastEnabledState(_set);
        } catch (Exception e) {
            Log.d(TAG, "setToasts: " + e);
            return false;
        }
        return true;
    }

    // TODO false -> block ; true -> unlock
    public boolean setLockPhone(boolean _set) {
        try {
            setLockScreenState(_set);
            setNFC(_set);
            setToasts(_set);
            kcsm.setDeviceSpeakerEnabledState(_set ? false : true);

            // 2 hiden -- 3  la hien
            //kcsm.setStatusBarMode(_set ? 2 : 3);
            kcsm.setStatusBarNotificationsState(_set);
            // _set am cua he thong
            for (int i = 1; i <= 5; i++) {
                kcsm.setAudioVolume(i, _set ? 0 : 0);
            }
            KioskMode kioskModeService = edm.getKioskMode();
            int A[] = {KeyEvent.KEYCODE_VOLUME_UP,
                    KeyEvent.KEYCODE_VOLUME_DOWN,
                    KeyEvent.KEYCODE_HOME,
                    KeyEvent.KEYCODE_BACK,
                    KeyEvent.KEYCODE_MENU,
                    KeyEvent.KEYCODE_APP_SWITCH,
                    KeyEvent.KEYCODE_POWER
            };
            List<Integer> list = new ArrayList();
            for (int i = 0; i < A.length; i++) {
                list.add(A[i]);
            }
            kioskModeService.allowEdgeScreen(KioskMode.EDGE_FUNCTION_ALL, _set);
            // disable provided keys
            kioskModeService.hideSystemBar(_set ? false : true);
            kioskModeService.hideStatusBar(_set ? false : true);
            kioskModeService.allowHardwareKeys(list, _set);
        } catch (Exception e) {
            Log.d(TAG, "setLockPhone: " + e);
            return false;
        }
        return true;

    }

    // false -> tunr off ; true turn On
    public void setScreenWakeUp(boolean _set) {
        SettingsManager stm = CustomDeviceManager.getInstance().getSettingsManager();
        stm.setScreenWakeupOnPowerState(_set);


    }
    public boolean ExitApp() {
        try {
            setLockPhone(true);
            setRemoveApp(true);
            setAdminRemovable(true);
            setResetFactory(true);
            setShowdow(true);
            setLockScreenState(true);
            removeActiveAdmin();
        } catch (Exception e) {
            Log.d(TAG, "ExitApp: " + e);
            return false;
        }
        return true;
    }

}
