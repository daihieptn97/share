package com.svmc.t15.security.LoginPassWord;

import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.svmc.t15.security.CODEKEY;
import com.svmc.t15.security.R;

public class ChangePassWord extends Activity implements View.OnClickListener {
    public static Activity changePassWord;
    private EditText edtPass, edtNewPass, edtConfirmPass;
    private ImageButton img1, img2, img3;
    private TextView textViewContenPass;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_pass_word);
        changePassWord = this;
        Init();
        setColorStatusBar();

        img1.setOnClickListener(this);
        img2.setOnClickListener(this);
        img3.setOnClickListener(this);
        CheckLeng();
        isLengPass();
    }

    private void CheckLeng() {
        edtPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                isLengPass();

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        edtNewPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                isLengPass();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        edtConfirmPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                isLengPass();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void isLengPass() {

        int A[] = {edtConfirmPass.length(), edtNewPass.length(), edtPass.length()};
        boolean isLeng = true;
        for (int i = 0; i < A.length; i++) {
            if (A[i] < 4 || A[i] > 16) {
                isLeng = false;
                break;
            }
        }
        if (isLeng) {

            if (edtNewPass.getText().toString().equals(edtConfirmPass.getText().toString())) {
                btnLogin.setClickable(true);
                btnLogin.setTextColor(getColor(R.color.textButton));
                textViewContenPass.setText("");
            } else {
                textViewContenPass.setText(R.string.password_is_not_same);
            }

            return;
        } else {
            textViewContenPass.setText(R.string.leng_pass);
            btnLogin.setClickable(false);
            btnLogin.setTextColor(getColor(R.color.colorTextDisable));

        }


    }

    private void setColorStatusBar() {
        Window window = getWindow();

        // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.backgroundHeader));
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    private void Init() {
        img1 = findViewById(R.id.imgBtnEye1);
        img2 = findViewById(R.id.imgBtnEye2);
        img3 = findViewById(R.id.imgBtnEye3);
        textViewContenPass = findViewById(R.id.txtContenPass);
        edtPass = findViewById(R.id.edtPassword);
        edtNewPass = findViewById(R.id.edtPasswordNew);
        edtConfirmPass = findViewById(R.id.edtPasswordConfirm);
        btnLogin = findViewById(R.id.btn_savePass);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckUpdatePass();
            }
        });
        findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private boolean isShowPass1 = false, isShowPass2 = false, isShowPass3 = false;

    private boolean listPassShow[] = {false, false, false};


    private void doShowPass(int index, EditText edt, ImageButton img) {
        if (!listPassShow[index]) {
            edt.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            listPassShow[index] = true;
            img.setImageResource(R.drawable.ic_hide_eye);

        } else {
            edt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            listPassShow[index] = false;
            img.setImageResource(R.drawable.ic_show_eye);
        }
        edt.setSelection(edt.getText().length());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgBtnEye1: {

                doShowPass(0, edtPass, img1);
                break;
            }
            case R.id.imgBtnEye2: {
                doShowPass(1, edtNewPass, img2);
                break;
            }
            case R.id.imgBtnEye3: {
                doShowPass(2, edtConfirmPass, img3);
                break;
            }
        }
    }

    private void CheckUpdatePass() {
        String pass_d = edtPass.getText().toString();
        String pass_new = edtNewPass.getText().toString();
        String pass_new_confirm = edtConfirmPass.getText().toString();

        // TODO check password
        if (CheckPass(pass_d)) {
            textViewContenPass.setTextColor(getResources().getColor(R.color.colorRed));
            textViewContenPass.setText(R.string.leng_pass);
            //  Toast.makeText(changePassWord, "Wrong PassWord", Toast.LENGTH_SHORT).show();
            return;
        }


        String pass_n = getSharedPreferences(CODEKEY.KEY_PASS, MODE_PRIVATE).getString(CODEKEY.KEY_PASS, null);
        if (pass_n.equals(CODEKEY.getMD5(pass_d))) {
            if (CheckPass(pass_new)) {

                Toast.makeText(changePassWord, R.string.leng_pass, Toast.LENGTH_SHORT).show();
                return;
            }
            if (CheckPass(pass_new_confirm)) {
                Toast.makeText(changePassWord, R.string.leng_pass, Toast.LENGTH_SHORT).show();
                return;
            }
            if (pass_new.equals(pass_new_confirm)) {

                getSharedPreferences(CODEKEY.KEY_PASS, MODE_PRIVATE).edit().putString(CODEKEY.KEY_PASS,
                        CODEKEY.getMD5(edtConfirmPass.getText().toString())).commit();
                finish();
            } else {
                textViewContenPass.setText(R.string.password_is_not_same);
                //Toast.makeText(changePassWord,"New passwords are not the same", Toast.LENGTH_SHORT).show();
                return;
            }
        } else {
            textViewContenPass.setText(R.string.wrongpassword);
            // Toast.makeText(changePassWord, "Wrong PassWord", Toast.LENGTH_SHORT).show();
            return;
        }
    }

    public static boolean CheckPass(String pass) {
        if (pass.length() >= 4 && pass.length() <= 16) {
            return false;
        } else
            return true;
    }
}
