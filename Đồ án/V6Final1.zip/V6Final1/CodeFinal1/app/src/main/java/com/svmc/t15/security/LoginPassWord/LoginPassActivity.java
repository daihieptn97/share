package com.svmc.t15.security.LoginPassWord;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.svmc.t15.security.CODEKEY;
import com.svmc.t15.security.FLAG_DEBUG;
import com.svmc.t15.security.Knox.MyKnox;
import com.svmc.t15.security.NFC.Activity_NFC;
import com.svmc.t15.security.R;

import org.w3c.dom.Text;

public class LoginPassActivity extends Activity {

    private int CODE_CHECK;
    private TextView txtConten , txtShowErro ,txtWarningSetPassword;
    private String newPass;
    private SharedPreferences pre;
    public static Activity loginPass, Regiter;
    private ImageButton btnIsShowPass;
    private EditText edtPassword;
    private boolean isShowPass = false;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_pass);
        Init();
        doSetContinue(false);
        findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int KEY = getIntent().getIntExtra(CODEKEY.KEY_ACTIVITY_NFC, -1);
                if (KEY == 200) {
                    return;
                }
                finish();

            }
        });
        btnIsShowPass = findViewById(R.id.imgBtnEye);
        btnIsShowPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isShowPass) {
                    edtPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    isShowPass = true;
                    btnIsShowPass.setImageResource(R.drawable.ic_hide_eye);
                } else {
                    edtPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    isShowPass = false;
                    btnIsShowPass.setImageResource(R.drawable.ic_show_eye);
                }
                edtPassword.setSelection(edtPassword.getText().length());
            }
        });

        edtPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                txtShowErro.setText("");
                Log.d(FLAG_DEBUG.SHOW_ACTIVITY_FLAG, start + " " + count + " " + before + " : " + s);
                if (checkPassword(start).equals("1")) {
                    doSetContinue(true);
                } else {
                    doSetContinue(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        setColorStatusBar();
    }

    private void doSetContinue(boolean c) {
        if (c) {
            btnLogin.setClickable(true);
            btnLogin.setTextColor(getColor(R.color.textButton));
        } else {
            btnLogin.setClickable(false);
            btnLogin.setTextColor(getColor(R.color.colorTextDisable));
        }
    }

    public String checkPassword(int length) {
        if (length < 3 || length > 15) {
            return getString(R.string.warringSetPassword);
        }
        return "1";
    }

    private void setColorStatusBar() {
        Window window = getWindow();

        // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.backgroundHeader));
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    private void Init() {
        txtWarningSetPassword = findViewById(R.id.txtWarningSetPassword);
        txtShowErro = findViewById(R.id.txtShowErro);
        CODE_CHECK = getIntent().getIntExtra(CODEKEY.KEY_ACTIVITY_NFC, -1);
        edtPassword = findViewById(R.id.edtPassword);
        txtConten = findViewById(R.id.txtContenPass);
        pre = getSharedPreferences(CODEKEY.KEY_PASS, MODE_PRIVATE);
        btnLogin = findViewById(R.id.btn_login);
        CheckCode();
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActionCode();
            }
        });
    }

    // TODO: Set Text
    private void CheckCode() {
        if (CODE_CHECK == CODEKEY.VALUE_SIGIN) {
            loginPass = this;
            txtConten.setText(getResources().getString(R.string.Creat_PASS));
        }
        if (CODE_CHECK == CODEKEY.VALUE_LOCK || CODE_CHECK == CODEKEY.VALUE_LOGIN) {
            txtConten.setText(getResources().getString(R.string.UnLock_PASS));
            txtWarningSetPassword.setText("");
            MyKnox myKnox = new MyKnox(this);
            myKnox.setToasts(true);
        }
        if (CODE_CHECK == CODEKEY.VALUE_LOGOUT) {
            txtWarningSetPassword.setText("");
            txtConten.setText(getResources().getString(R.string.Logout_PASS));
        }
        if (CODE_CHECK == CODEKEY.VALUE_CONFIRM) {
            Regiter = this;
            txtWarningSetPassword.setText("");
            txtConten.setText(getResources().getString(R.string.Creat_PASS_CONFIRM));
        }

    }

    // TODO: xác nhận xem activity đang thực hiện hành động gì
    private void ActionCode() {
        String pass = edtPassword.getText().toString();

        if (ChangePassWord.CheckPass(pass)) {
           // Toast.makeText(loginPass, R.string.leng_pass, Toast.LENGTH_SHORT).show();
            return;
        }
        pass = CODEKEY.getMD5(pass);

        if (CODE_CHECK == CODEKEY.VALUE_SIGIN) {
            Intent intent = new Intent(LoginPassActivity.this, LoginPassActivity.class);
            intent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_CONFIRM);
            intent.putExtra(CODEKEY.KEY_PASS, pass);
            startActivity(intent);
            //finish();
            return;
        }

        if (CODE_CHECK == CODEKEY.VALUE_LOCK) {
            String PASS = GetPASS();
            if (pass.equals(PASS)) {
                Intent intent = new Intent(LoginPassActivity.this, Activity_NFC.class);
                intent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_LOCK);
                startActivity(intent);
                finish();
            } else {
                txtShowErro.setText(R.string.wrongpassword);
                return;
            }
        }
        if (CODE_CHECK == CODEKEY.VALUE_LOGIN) {
            String PASS = GetPASS();
            if (pass.equals(PASS)) {
                Intent intent = new Intent(LoginPassActivity.this, Activity_NFC.class);
                intent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_LOGIN);
                startActivity(intent);
                finish();
            } else {
                txtShowErro.setText(R.string.wrongpassword);
                return;
            }
        }

        if (CODE_CHECK == CODEKEY.VALUE_LOGOUT) {
            String PASS = GetPASS();
            if (pass.equals(PASS)) {

                Intent intent = new Intent(LoginPassActivity.this, Activity_NFC.class);
                intent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_LOGOUT);
                startActivityForResult(intent, CODEKEY.VALUE_LOGOUT);
            } else {
                txtShowErro.setText(R.string.wrongpassword);
            //    Toast.makeText(this, "Wrong Password", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (CODE_CHECK == CODEKEY.VALUE_CONFIRM) {
            newPass = this.getIntent().getStringExtra(CODEKEY.KEY_PASS);
            if (pass.equals(newPass)) {
                Intent intent = new Intent(LoginPassActivity.this, Activity_NFC.class);
                intent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_SIGIN);
                SetPASS(newPass);
                startActivity(intent);
                finish();
            } else {
                txtShowErro.setText(R.string.password_is_not_same);
                //Toast.makeText(this, , Toast.LENGTH_SHORT).show();
                return;
            }
        }


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CODEKEY.VALUE_LOGOUT) {
            if (resultCode == Activity.RESULT_OK) {
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_OK, returnIntent);
                finish();
            }
        }
    }

    private String GetPASS() {
        return getSharedPreferences(CODEKEY.KEY_PASS, MODE_PRIVATE).getString(CODEKEY.KEY_PASS, null);
    }

    private void SetPASS(String pass) {
        getSharedPreferences(CODEKEY.KEY_PASS, MODE_PRIVATE).edit().putString(CODEKEY.KEY_PASS, pass).commit();
    }
}
