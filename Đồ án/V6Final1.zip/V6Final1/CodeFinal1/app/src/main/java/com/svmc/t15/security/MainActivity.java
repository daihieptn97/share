package com.svmc.t15.security;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.svmc.t15.security.DeviceAdmin.SampleAdminReceiver;
import com.svmc.t15.security.LoginPassWord.LoginPassActivity;
import com.svmc.t15.security.Services.DockListenerServices;
import com.svmc.t15.security.Services.VideoService;

public class MainActivity extends Activity {
    private static final int DEVICE_ADMIN_ADD_RESULT_ENABLE = 1;
    private String TAG = "DEBUG";
    private String strPASS;
    private String strNFC;
    public static Activity contextMainActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //TODO Start Sevice
        StarSevice();
        setContentView(R.layout.activity_main);
        SetColorBar();
        Init();
        //  AtiveAdmin();
        //   RequestPermission();
        contextMainActivity = this;
    }


    //    TODO Test
    private void SetColorBar() {
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.ColorWhite));
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    private void StarSevice() {
        if (!isMyServiceRunning(VideoService.class)) {
            Intent intent = new Intent(this, VideoService.class);
            startService(intent);
        }

        if (!isMyServiceRunning(DockListenerServices.class)) {
            Intent intent = new Intent(this, DockListenerServices.class);
            startService(intent);
        }
    }


    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void Init() {
        strPASS = GetPASS();
        strNFC = GetNFC();

        if (!isNullPASS() && !isNullNFC()) {
            int CODE_CHECK = -1;
            try {
                CODE_CHECK = getIntent().getIntExtra(CODEKEY.KEY_ACTIVITY_NFC, -1);
            } catch (Exception e) {
                CODE_CHECK = -1;
            }
            Log.d(TAG, "Init: " + CODE_CHECK);
            Intent myintent = new Intent(MainActivity.this, LoginPassActivity.class);
            if (CODE_CHECK == CODEKEY.VALUE_LOCK) {

                myintent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_LOCK);
            } else {
                //Toast.makeText(contextMainActivity, CODE_CHECK, Toast.LENGTH_SHORT).show();
                myintent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_LOGIN);
            }
            startActivity(myintent);
            finish();
            return;
        }

        findViewById(R.id.btnStart).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AtiveAdmin();
                RequestPermission();
//                Intent intent = new Intent(MainActivity.this, LoginPassActivity.class);
//                intent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_SIGIN);
//                startActivity(intent);
                //finish();
            }
        });
    }

    private void AtiveAdmin() {
        ComponentName mDeviceAdmin = new ComponentName(this, SampleAdminReceiver.class);
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        boolean adminActive = dpm.isAdminActive(mDeviceAdmin);
        if (!adminActive) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mDeviceAdmin);
            startActivityForResult(intent, DEVICE_ADMIN_ADD_RESULT_ENABLE);
        } else {
            Intent intent = new Intent(MainActivity.this, LoginPassActivity.class);
            intent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_SIGIN);
            startActivity(intent);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DEVICE_ADMIN_ADD_RESULT_ENABLE) {
            switch (resultCode) {
                // End user cancels the request
                case Activity.RESULT_CANCELED:
                    Log.d(TAG, "onActivityResult: CANCELED");
                    this.finish();
                    break;
                case Activity.RESULT_OK:
                    Log.d(TAG, "onActivityResult: RESULT OK");
                    Intent intent = new Intent(MainActivity.this, LoginPassActivity.class);
                    intent.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_SIGIN);
                    startActivity(intent);
                    break;
                default:
                    this.finish();
                    break;
            }
        }
    }

    // @RequiresApi(api = Build.VERSION_CODES.P)
    private void RequestPermission() {
        // Check if Android M or higher

        // Here, thisActivity is the current activity
        if (
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                        ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                        ContextCompat.checkSelfPermission(this, Manifest.permission.WAKE_LOCK) != PackageManager.PERMISSION_GRANTED
        ) {

            // Permission is not granted
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_CONTACTS)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                ActivityCompat.requestPermissions(this, new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.WAKE_LOCK,
                }, 6454540);
            }
        } else {
            // Permission has already been granted
        }
        checkDrawOverlayPermission(this);
    }

    public void checkDrawOverlayPermission(Context context) {
        // check if we already  have permission to draw over other apps
        if (Settings.canDrawOverlays(context)) {
            // code
        } else {
            // if not construct intent to request permission
            final Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, 12345);
        }
    }


    public boolean isNullPASS() {
        return strPASS == null ? true : false;
    }

    public boolean isNullNFC() {
        return strNFC == null ? true : false;
    }

    private void SetNFC(String nfc) {
        getSharedPreferences(CODEKEY.KEY_NFC, MODE_PRIVATE).edit().putString(CODEKEY.KEY_NFC, nfc);
    }

    private String GetNFC() {
        return getSharedPreferences(CODEKEY.KEY_NFC, MODE_PRIVATE).getString(CODEKEY.KEY_NFC, null);
    }

    private String GetPASS() {
        return getSharedPreferences(CODEKEY.KEY_PASS, MODE_PRIVATE).getString(CODEKEY.KEY_PASS, null);
    }

    private void SetPASS(String pass) {
        getSharedPreferences(CODEKEY.KEY_PASS, MODE_PRIVATE).edit().putString(CODEKEY.KEY_PASS, pass);
    }
}
