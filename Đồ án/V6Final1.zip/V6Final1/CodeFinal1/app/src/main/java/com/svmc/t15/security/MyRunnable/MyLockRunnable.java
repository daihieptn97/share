package com.svmc.t15.security.MyRunnable;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.core.content.ContextCompat;

import com.svmc.t15.security.R;

public class MyLockRunnable implements Runnable {
    private int ArrayImg[] = {R.drawable.ic_warning_1, R.drawable.ic_warning_2};
    private String ArrayColor[] = {"#FFFF1744", "#FFE529"};
    private int Dem = 0;
    private LinearLayout linearLayout;
    private ImageView imageView;
    private boolean Set ;
    private Activity activity;

    public MyLockRunnable(LinearLayout linearLayout, ImageView imageView , Activity activity) {
        this.linearLayout = linearLayout;
        this.imageView = imageView;
        this.activity =activity;
        Set  = true;
    }

    public  void setStop(boolean set){
        Set = set;
    }

    @Override
    public void run() {
        try {

            while (Set) {
                linearLayout.setBackgroundColor(Color.parseColor(ArrayColor[Dem]));
                imageView.setImageResource(ArrayImg[Dem]);
                Dem = (Dem + 1) % 2;
                Log.d("Bug", "run: " + Dem);

                Thread.sleep(500);
            }
            if( Set == false)return;
        } catch (Exception e) {
            Log.d("bug", "run: "+e);
        }
    }
}
