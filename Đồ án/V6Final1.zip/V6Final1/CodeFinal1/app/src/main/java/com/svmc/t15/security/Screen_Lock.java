package com.svmc.t15.security;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.svmc.t15.security.Knox.MyKnox;
import com.svmc.t15.security.MyRunnable.MyLockRunnable;

public class Screen_Lock extends Activity {
    public static Activity contextSceenLock;
    private MediaPlayer mediaPlayer;
    private Context context;
    private LinearLayout linearLayout;
    private ImageView imageView;
    private Thread myThread;
    private MyLockRunnable myLockRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Remove
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_screen__lock);
        contextSceenLock = this;
        Init();
        MyKnox myKnox = new MyKnox(this);
        myKnox.setToasts(false);


    }

    private void setColorStatusBar() {
        Window window = getWindow();

        // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.backgroundHeader));
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }


    private void Init() {
        mediaPlayer = MediaPlayer.create(this, R.raw.sound_file_1);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
        linearLayout = findViewById(R.id.line_acitivity_screenLock);
        imageView = findViewById(R.id.img_logoWarning);

        myLockRunnable = new MyLockRunnable(linearLayout, imageView , this);
        myThread = new Thread(myLockRunnable);
        myThread.start();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        myLockRunnable.setStop(false);
        myThread = null;
        myLockRunnable = null;

    }
}
