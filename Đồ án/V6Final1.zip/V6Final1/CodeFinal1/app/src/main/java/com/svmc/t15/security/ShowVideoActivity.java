package com.svmc.t15.security;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;


import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.ui.PlayerView;
import com.svmc.t15.security.Knox.MyKnox;
import com.svmc.t15.security.object.VideoRun;
import com.svmc.t15.security.ultils.TimeHandler;
import com.svmc.t15.security.ultils.VideoHandler;

import java.io.File;
import java.util.List;
import java.util.Random;

public class ShowVideoActivity extends Activity implements View.OnClickListener {
    public static boolean activeVideoActivity = false;
    private PlayerView playerView;
    private ImageButton btnPlay, btnPause;
    private SimpleExoPlayer player;
    private long timeStartCurrent = 0;
    private VideoHandler videoHandler;

    private List<String> uriVideos;
    private int videoIndex = 0;
    private Context context;
    public static ShowVideoActivity showVideoActivity;
    private MediaSource[] listMediaSources;
    boolean isSetValueVideo = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);
        setContentView(R.layout.activity_show_video);
        context = this;
        showVideoActivity = this;
        mappingView();
        hideSystemUI(); // hidden navigation key

        wakeupScreen(); // wake screen when it turn off or lock!

        initializePlayer();

        playerView.setOnClickListener(this);
        btnPause.setOnClickListener(this);
        btnPlay.setOnClickListener(this);

        //  getWindow().addFlags(WindowManager.LayoutParams.PREVENT_POWER_KEY);
    }

    public void addItem() {
        // Add mediaId (e.g. uri) as tag to the MediaSource.
        listMediaSources = new MediaSource[uriVideos.size()];
        for (int i = 0; i < uriVideos.size(); i++) {
            listMediaSources[i] = VideoHandler.buildMediaSource(Uri.parse(uriVideos.get(i)), this);
        }
        VideoRun t = TimeHandler.startTime(videoHandler);
        videoIndex = t.getIndex();
        player.prepare(listMediaSources[videoIndex]);
        player.setPlayWhenReady(true);

    }

    boolean c = true;
    public void setTime() {
        new Thread() {
            @Override
            public void run() {
                try {
                    this.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                // your code here
                long currentTimeVideo = System.currentTimeMillis() % videoHandler.getTotalTimeVideos();
                Random rand = new Random();
                player.seekTo((currentTimeVideo - timeStartCurrent) - (long) rand.nextInt(500));
                Log.d(FLAG_DEBUG.VIDEO_HANDLER_FLAG, "reload.");

            }
        }.start();
    }

    private void initializePlayer() {
//        player.release();
        if (uriVideos.size() > 0) { // file exists
            playerView.setPlayer(player);
            addItem();
            player.addListener(new Player.EventListener() {
                @Override
                public void onLoadingChanged(boolean isLoading) {

                }

                @Override
                public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {
                    switch (playbackState) {
                        case Player.STATE_READY:
                            if (isSetValueVideo) {
                                VideoRun t = TimeHandler.startTime(videoHandler);
                                timeStartCurrent = t.getTimeStart();
                                videoIndex = t.getIndex();
                                player.prepare(listMediaSources[videoIndex]);

                                long currentTimeVideo = System.currentTimeMillis() % videoHandler.getTotalTimeVideos();
                                Random rand = new Random();
                                player.seekTo((currentTimeVideo - timeStartCurrent) - (long) rand.nextInt(500));

                                Log.d(FLAG_DEBUG.VIDEO_HANDLER_FLAG, System.currentTimeMillis() + "");
                                Log.d(FLAG_DEBUG.SHOW_ACTIVITY_FLAG, "STATE_READY " + videoIndex + " " + timeStartCurrent + " " + currentTimeVideo);
                                isSetValueVideo = false;

                                setTime();
                            }
                            break;
                        case Player.STATE_BUFFERING:
                            break;
                        case Player.STATE_IDLE:
                            Log.d(FLAG_DEBUG.SHOW_ACTIVITY_FLAG, "STATE_IDLE");
                            isSetValueVideo = true;
                            break;
                        case Player.STATE_ENDED: {
                            Log.d(FLAG_DEBUG.SHOW_ACTIVITY_FLAG, "STATE_ENDED");
                            videoIndex = videoHandler.nextVideo(videoIndex);
                            player.prepare(listMediaSources[videoIndex]);
                            player.seekTo(0);
                            break;
                        }
                    }
                }
            });
        }
    }


    private void mappingView() {
        playerView = findViewById(R.id.pvShowVideoInto);
        btnPause = findViewById(R.id.exo_pause);
        btnPlay = findViewById(R.id.exo_play);

        videoHandler = new VideoHandler(this);
        uriVideos = videoHandler.getListFiles(new File(Environment.getExternalStorageDirectory() + "/intro"));
        //  Log.d("haha", uriVideos.toString());
        player = new SimpleExoPlayer.Builder(this).build();
    }

    public void wakeupScreen() {
        @SuppressLint("InvalidWakeLockTag") PowerManager.WakeLock screenLock = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "TAG");
        screenLock.acquire();
        screenLock.release();
    }

    private void hideSystemUI() {
        // Enables regular immersive mode.
        // For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
        // Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    @Override
    protected void onStart() {
        super.onStart();
        hideSystemUI();
        activeVideoActivity = true;
    }

    @Override
    protected void onStop() {
        super.onStop();
        activeVideoActivity = false;


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        activeVideoActivity = false;
        player.stop();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.pvShowVideoInto:
            case R.id.exo_play:
            case R.id.exo_pause: {
                ShowVideoActivity.this.finish();
                break;
            }
        }
    }
}
