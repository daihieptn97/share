package com.svmc.t15.security.broadcast;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.util.Log;
import android.widget.Toast;

import com.svmc.t15.security.Alram.AlarmShowVideo;
import com.svmc.t15.security.FLAG_DEBUG;
import com.svmc.t15.security.Services.VideoService;
import com.svmc.t15.security.ShowVideoActivity;

import static android.content.Context.POWER_SERVICE;

public class AlarmBroadcast extends BroadcastReceiver {
    @Override
    public void onReceive( Context context, Intent intent) {
        int extra = intent.getIntExtra(Intent.EXTRA_ALARM_COUNT, -1);
        Log.d(FLAG_DEBUG.SHOW_ACTIVITY_FLAG, intent.getAction());
        if (extra != -1 && intent.getAction().equals(AlarmShowVideo.ACTION_SET_TIME_ON)) {
         //   Toast.makeText(context, "Running video.", Toast.LENGTH_SHORT).show();
            /*start code*/
//            if (!isMyServiceRunning(VideoService.class, context)) {
//                Intent intent1 = new Intent(context, VideoService.class);
//                context.startService(intent1);
//            }
            wakeupScreen(context);
            Intent intent1 = new Intent(context, VideoService.class);
            context.startForegroundService(intent1);

            /*end code*/

        }

        if (extra != -1 && intent.getAction().equals(AlarmShowVideo.ACTION_SET_TIME_OFF)) {
         //   Toast.makeText(context, "Stop video.", Toast.LENGTH_SHORT).show();
            /*start code*/
            context.stopService(new Intent(context, VideoService.class));
            if (ShowVideoActivity.showVideoActivity != null) {
                ShowVideoActivity.showVideoActivity.finish();
            }
            /*End code*/
        }
    }

    public void wakeupScreen(Context context) {
        @SuppressLint("InvalidWakeLockTag") PowerManager.WakeLock screenLock = ((PowerManager) context.getSystemService(POWER_SERVICE)).newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "TAG");
        screenLock.acquire();
        screenLock.release();
    }

    private boolean isMyServiceRunning(Class<?> serviceClass, Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}
