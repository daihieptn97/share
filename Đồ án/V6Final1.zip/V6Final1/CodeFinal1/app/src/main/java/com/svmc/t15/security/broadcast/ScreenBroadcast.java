package com.svmc.t15.security.broadcast;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.util.Log;
import android.widget.Toast;

import com.svmc.t15.security.CODEKEY;
import com.svmc.t15.security.Knox.MyKnox;
import com.svmc.t15.security.MainActivity;
import com.svmc.t15.security.Screen_Lock;
import com.svmc.t15.security.ShowVideoActivity;


public class ScreenBroadcast extends BroadcastReceiver {
    private MyKnox myKnox;

    private String MYKEY = "04e8:a034";

    @Override
    public void onReceive(Context context, Intent intent) {

        //onListen(context, intent);


        String strNFC = context.getSharedPreferences(CODEKEY.KEY_NFC, Context.MODE_PRIVATE).getString(CODEKEY.KEY_NFC, null);
        String strPass = context.getSharedPreferences(CODEKEY.KEY_PASS, Context.MODE_PRIVATE).getString(CODEKEY.KEY_PASS, null);

        if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF) && !ShowVideoActivity.activeVideoActivity && (strNFC != null && strPass != null)) {

            Intent a = new Intent(context, ShowVideoActivity.class);
            Log.d("bug", "onReceive: video");
            a.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TOP |
                            Intent.FLAG_ACTIVITY_NO_HISTORY);
            context.startActivity(a);
        }
    }

    private void onListen(Context context, Intent intent) {

        myKnox = new MyKnox(context);
        if (intent.getAction().equals(Intent.ACTION_DOCK_EVENT)) {

            CODEKEY codekey = new CODEKEY();
            int CODE = intent.getIntExtra("android.intent.extra.DOCK_STATE", -1);
            String KEY = intent.getStringExtra("com.sec.intent.extra.DOCK_ID");

            String strNFC = context.getSharedPreferences(CODEKEY.KEY_NFC, Context.MODE_PRIVATE).getString(CODEKEY.KEY_NFC, null);
            String strPass = context.getSharedPreferences(CODEKEY.KEY_PASS, Context.MODE_PRIVATE).getString(CODEKEY.KEY_PASS, null);

            if (strNFC == null || strPass == null) {
                if (CODE == 0) { // command comment when not put cap
                  //  System.exit(0);
                }
                return;
            }

            if (CODE == 0 || KEY == null) {
                codekey.TurnOfAtivity();
                myKnox.setLockPhone(false);
                //TODO : khi rut sach . kiem tra pass voi NFC co hay khong, neu co khoa lai va keu
                Intent intentMain = new Intent(context, Screen_Lock.class);
                intentMain.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intentMain);
            }
            if (CODE == 200 && KEY.equals(MYKEY)) {
                codekey.TurnOfAtivity();
                // TODO : neu cam lai thi yeu cau mat khau
                Intent intentMain = new Intent(context, MainActivity.class);
                intentMain.putExtra(CODEKEY.KEY_ACTIVITY_NFC, CODEKEY.VALUE_LOCK);
                intentMain.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intentMain);

            }
        }
    }
}
