package com.svmc.t15.security.object;

public class VideoRun {
    private int index;
    private long timeStart;

    public VideoRun(int index, long timeStart) {
        this.index = index;
        this.timeStart = timeStart;
    }

    public void setTimeStart(long timeStart) {
        this.timeStart = timeStart;
    }

    public int getIndex() {
        return index;
    }

    public long getTimeStart() {
        return timeStart;
    }
}
