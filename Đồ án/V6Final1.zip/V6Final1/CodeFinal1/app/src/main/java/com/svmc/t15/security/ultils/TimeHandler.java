package com.svmc.t15.security.ultils;

import com.svmc.t15.security.object.VideoRun;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TimeHandler {
    public static VideoRun startTime(VideoHandler videoHandler) {
        long currentTimeVideo = System.currentTimeMillis() % videoHandler.getTotalTimeVideos();
        VideoRun videoRun = videoHandler.getVideoRunningInCurrentTime(currentTimeVideo);

     /*   Log.d(FLAG_DEBUG.VIDEO_HANDLER_FLAG,
                videoRun.getIndex() + " - "
                        + "\n videoRun.getTimeStart " + videoRun.getTimeStart()
                        + "\n currentTimeVideo : " + currentTimeVideo
                        + "\n System.currentTimeMillis() : " + System.currentTimeMillis()
                        + "\n videoHandler.getTotalTimeVideos : " + videoHandler.getTotalTimeVideos()
        );*/
//        videoRun.setTimeStart( videoRun.getTimeStart());
        return videoRun;
    }

    public static long timeCurrentTypeSeconds() {
        //String time = "02:30"; //mm:ss

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String time = dtf.format(now);

        String[] units = time.split(":"); //will break the string up into an array
        int minutes = Integer.parseInt(units[0]); //first element
        int h = Integer.parseInt(units[1]); //first element
        int seconds = Integer.parseInt(units[2]); //second element
        int duration = (h * 60 + minutes) * 60 + seconds; //add up our values

        return duration * 1000;
    }
}
