package com.svmc.t15.security.ultils;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;

import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.svmc.t15.security.object.VideoRun;


import java.io.File;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class VideoHandler {

    private long totalTimeVideos = 0;
    private long timeVideoLast = 0;
    private List<Long> timeStartVideo;
    private SimpleExoPlayer player;
    private Context context;

    public long getTotalTimeVideos() {
        return totalTimeVideos;
    }

    public long getTimeVideoLast() {
        return timeVideoLast;
    }

    public List<Long> getTimeStartVideo() {
        return timeStartVideo;
    }

    public VideoHandler(Context context) {
        this.context = context;
        player = new SimpleExoPlayer.Builder(context).build();
        timeStartVideo = new ArrayList<>();
    }

    public List<String> sort1(List<String> myArray) {
        int size = myArray.size();

        for (int i = 0; i < size - 1; i++) {
            for (int j = i + 1; j < myArray.size(); j++) {
                if (myArray.get(i).toLowerCase().compareTo(myArray.get(j).toLowerCase()) > 0) {
                    String temp = myArray.get(i);
                    myArray.set(i, myArray.get(j));
                    myArray.set(j, temp);
                }
            }
        }

        return myArray;
    }

    public List<String> getListFiles(File parentDir) {
        List<String> inFiles = new ArrayList<String>();
        File[] files = parentDir.listFiles();
        for (File file : files) {
            if (files != null) {
                String uriFile = parentDir + "/" + file.getName();
                if (file.isDirectory()) {
                    //inFiles.addAll(getListFiles(file));
                } else if (isVideoFile(uriFile)) {
                    inFiles.add(uriFile);
//                    long timeVideo = getTimeVideo(uriFile);
//                    // Log.d(FLAG_DEBUG.VIDEO_HANDLER_FLAG, timeVideo + " - " + totalTimeVideos);
//                    timeStartVideo.add(totalTimeVideos);
//                    totalTimeVideos += timeVideo;
                }
            }
        }

        inFiles = sort1(inFiles);
        // Log.d("haha", inFiles.toString());

        for (int i = 0; i < inFiles.size() - 1; i++) {
            long timeVideo = getTimeVideo(inFiles.get(i));
            // Log.d(FLAG_DEBUG.VIDEO_HANDLER_FLAG, timeVideo + " - " + totalTimeVideos);
            timeStartVideo.add(totalTimeVideos);
            totalTimeVideos += timeVideo;
        }

        return inFiles;
    }

    public VideoRun getVideoRunningInCurrentTime(long timeVideoCurrent) {

        long lastTime = 0;
        int i = 0;
        while (i < timeStartVideo.size() && timeVideoCurrent > timeStartVideo.get(i)) {
            lastTime = timeStartVideo.get(i);
            i++;
        }
        VideoRun videoRun = new VideoRun(i - 1, lastTime);
        return videoRun;
    }

    public Long getTimeVideo(String url) {
        MediaPlayer mp = MediaPlayer.create(context, Uri.parse(url)); // Downloads is the folder and vid is video file.
        long duration = mp.getDuration();
        return duration;
    }

    public static MediaSource buildMediaSource(Uri uri, Activity context) {
        DataSource.Factory dataSourceFactory =
                new DefaultDataSourceFactory(context, "exoplayer-codelab");
        return new ProgressiveMediaSource.Factory(dataSourceFactory)
                .createMediaSource(uri);
    }

    public static boolean isVideoFile(String path) {
        String mimeType = URLConnection.guessContentTypeFromName(path);
        return mimeType != null && mimeType.startsWith("video");
    }

    public int nextVideo(int indexCurrent) {
        if (indexCurrent == timeStartVideo.size() - 1) {
            return 0;
        } else
            return indexCurrent + 1;
    }

}
